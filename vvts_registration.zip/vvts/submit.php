<?php
include_once('config/config.php');

if(isset($_POST["submit"])) 
{
        $name = $_POST["name"];
        $email_id = $_POST["email"];
        $mobile = $_POST["mbl"];
        $address = $_POST["address"];

        if (!$conn) 
        {
            die("Connection failed: " . mysqli_connect_error());
        }

        $sql2 = mysqli_query($conn,"SELECT email FROM user_registration WHERE email='$email_id'"); 
            if(mysqli_num_rows($sql2)>0)
            { 
              $fail='OOPS.... Email already registered to another account....';
              header("Location:index.php?fail=$fail");
              exit();
             }
        $sql3 = mysqli_query($conn,"SELECT phone FROM user_registration WHERE phone='$mobile'"); 
            if(mysqli_num_rows($sql3) >0)
            { 
              $fail='OOPS.... Mobile Number aleready registered to another account....  ';
              header("Location:index.php?fail=$fail");
              exit();
          }

          $sql = mysqli_query($conn,"INSERT INTO `user_registration`(`name`, `email`, `phone`, `address`) VALUES('$name','$email_id','$mobile','$address')");
          if($sql==TRUE)
          {
            
                 
			require('fpdf/fpdf.php');
			$pdf= new FPDF('p','mm','A4');
			$pdf->AddPage();
			$pdf->SetFont('Arial','B',14,1,0);
			$pdf->SetTextColor(0,0,255);
			$pdf->Cell(180 ,7,'VVTS Registration',0,1,'C');
			$pdf->SetFont('Arial','',12);
			$pdf->Ln(2);
			$pdf->SetTextColor(51,102,0);
			$pdf->Cell(40,7,'You have succesfully registered on VVTS') ;
			$pdf->Ln();
			$pdf->Ln(2 );
			$pdf->SetTextColor(0,0,0);
			$pdf->Cell(40 ,7,'Name:');
			$pdf->Cell(0 ,7,$name);
			$pdf->Ln(); 
			$pdf->Cell(40 ,7,'Email ID:');
			$pdf->Cell(0 ,7,$email_id);
			$pdf->Ln(); 
			$pdf->Cell(40 ,7,'Mobile Number:');
			$pdf->Cell(0 ,7,$mobile);
			$pdf->Ln();
			$pdf->Cell(40,7,'Address:');
			$pdf->Multicell(0,6,$address,0,1);
			$pdf->Ln();
			$pdf->SetFont('Arial','',10); 
			$pdf->Cell(180,7,'*** System Generated PDF ***',0,1,'R');
			$filename=str_replace(' ', '_',$name);
			$filename.="_"."$mobile".".pdf";
			$path="reg_user_pdf/$filename";
			$pdf->Output($path,'F');
			/*$suc='Registration completed Successfuly......';
            header("Location:index.php?suc=$suc");*/
            session_start();
		    $_SESSION['mail'] =$email_id;
		    $_SESSION['name'] =$name; 
		    $_SESSION['file'] = $filename;
		    $_SESSION['registered']=true;
		    header("Location:send_mail.php");
		    exit();  

          }
          else
          {
            echo "<span style='color:red'>opps.... Something Went wrong try again....</span>";
            echo mysqli_error($conn);
            exit();
          }


        
}
else
{
	header("Location:index.php");
}


?>