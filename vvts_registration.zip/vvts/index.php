<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
  <title>VVTS Registration Form</title>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
</head>
<body>
   <div class="container" id="startPosts" >
<br><br>
    <div class="row center-align">
    <div class="col s12">
      <div class="card white z-depth-5">
        <div class="card-content  center">
          <span class="card-title blue-text"><b><i>VVTS Registration Form</i></b></span>
          <form action="submit.php" method="post">
          <div class="input-field col s12">
            <i class="material-icons prefix">account_circle</i>
          <input id="name" name="name" type="text" class="validate black-text" required>
          <label for="name" class="black-text">Name</label>
          </div>
          <div class="input-field col s12">
            <i class="material-icons prefix">email</i>
          <input id="email" name="email" type="email" class="validate black-text" required>
          <label for="email" class="black-text">Email</label>
          </div>
          <div class="input-field col s12">
            <i class="material-icons prefix">phone</i>
          <input id="mbl" name="mbl" type="number" class="validate black-text" min="1000000000" max="9999999999"required>
          <label for="mbl" class="black-text">Phone</label>
          </div>
          <div class="input-field col s12">
            <i class="material-icons prefix">map</i>
          <textarea id="address" name="address" class="materialize-textarea" required></textarea>
          <label for="address"class="black-text">Address</label>
          </div>
          <br><br><br><br>
          <button class="btn waves-effect waves-light pulse indigo darken-4" type="submit" name="submit">Register
            <i class="material-icons right">send</i>
          </button>
        </form>
        <br><br>
        <div class="center">
          <?php
      if(isset($_GET['fail']))
        {
          $error=$_GET['fail'];
          echo "<span style='color:red;font-size:15px;'><b>$error</b></span>";
        }
      ?>
       <?php
      if(isset($_GET['suc']))
        {
          $msg=$_GET['suc'];
          echo "<span style='color:green;font-size:18px;'><b>$msg</b></span>";
        }
      ?>
        </div>
        </div>
        
        </div>
        </div>
          
      </div>
  </div>
  <!--  Scripts-->
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>
  
</body>
</html>
