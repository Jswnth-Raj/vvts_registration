<?php
session_start();
if($_SESSION['registered']==false || !isset($_SESSION['registered']))
{
    header("location:index.php");
}
else
{
require 'phpmailer/PHPMailerAutoload.php';

$mail = new PHPMailer;

//$mail->SMTPDebug = 3;                               // Enable verbose debug output

$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = 'noreply.vvts@gmail.com';                 // SMTP username
$mail->Password = 'Sample@vvts';                           // SMTP password
$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
$mail->Port = 587;                                    // TCP port to connect to

$mail->setFrom('noreply.vvts@gmail.com', 'Admin_VVTS');
$mail->addAddress($_SESSION['mail'],$_SESSION['name']);     // Add a recipient

$mail->Subject = 'VVTS Registration';
$mail->Body    = "Congratulations your Registration is successfull! Check your details in attached PDF";
//$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
$loc="reg_user_pdf/".$_SESSION['file'];
$mail->addAttachment($loc);

if(!$mail->send()) {

	$fail='Something went wrong while sending mail....';
              header("Location:index.php?fail=$fail");
              exit();
    
    
} else {

    $suc="Registration completed Successfuly......<br>We have sent you mail to ". $_SESSION['mail'];
   		
		session_unset();
		session_destroy();  
		mysqli_close($conn);
    header("Location:index.php?suc=$suc");
    exit();
            
}
}

?>