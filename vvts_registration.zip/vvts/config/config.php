<?php
$host="localhost";
$uname="root";
$password="";
$database="vvts_info";
$conn=mysqli_connect($host, $uname, $password, $database);
?>