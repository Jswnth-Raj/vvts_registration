**** Setup Instructions *****

Step 1: Copy all files to local server hosting area 
	Example in xampp  C->xampp->htdocs->paste_files

Step 2: Create database in phpmyadmin with the name "user_registration"

Step 3: Now import the database file in you phpmyadmin_database

**** All set now you can run the Website ***